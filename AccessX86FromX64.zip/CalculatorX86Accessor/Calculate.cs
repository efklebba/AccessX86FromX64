﻿using System.Threading.Tasks;
using System.Web.Script.Serialization;
using CalculatorX86;
using DataContract;

namespace CalculatorX86Accessor
{
    public class Calculate
    {
        public async Task<object> CalculationRequest(dynamic inputData)
        {
            object result = await Task.Run(() => PerformCalculation(inputData));
            return result;
        }

        private object PerformCalculation(dynamic inputData)
        {
            CalculatorOutput outputData = new CalculatorOutput();

            JavaScriptSerializer sr = new JavaScriptSerializer();
            CalculatorInput calculatorInput = sr.Deserialize<CalculatorInput>(inputData.Object);
            if (calculatorInput == null)
                return outputData;

            Calculator calculator = new Calculator();

            outputData.InputObject = calculatorInput;

            CalculatorAction actionId = calculatorInput.Action;
            switch (actionId)
            {
                case CalculatorAction.Add:
                    outputData.ResultOfOperation = calculator.Add(calculatorInput.Value1, calculatorInput.Value2);
                    break;
                case CalculatorAction.Subtract:
                    outputData.ResultOfOperation = calculator.Subtract(calculatorInput.Value1, calculatorInput.Value2);
                    break;
                case CalculatorAction.Multiply:
                    outputData.ResultOfOperation = calculator.Multiply(calculatorInput.Value1, calculatorInput.Value2);
                    break;
                case CalculatorAction.Divide:
                    outputData.ResultOfOperation = calculator.Divide(calculatorInput.Value1, calculatorInput.Value2);
                    break;
            }

            return outputData;
        }
    }
}
