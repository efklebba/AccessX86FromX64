﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Web.Script.Serialization;
using System.Windows;
using DataContract;

namespace AccessX86FromX64
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        { InitializeComponent(); }

        private void Add_OnClick(object sender, RoutedEventArgs e)
        { Get(CalculatorAction.Add); }

        private void Subtract_OnClick(object sender, RoutedEventArgs e)
        { Get(CalculatorAction.Subtract); }

        private void Multiply_OnClick(object sender, RoutedEventArgs e)
        { Get(CalculatorAction.Multiply); }

        private void Divide_OnClick(object sender, RoutedEventArgs e)
        { Get(CalculatorAction.Divide); }

        private void Get(CalculatorAction action)
        {
            CalculatorInput inputData = new CalculatorInput
            {
                Action = action,
                Value1 = Double.Parse(txtValue1.Text),
                Value2 = Double.Parse(txtValue2.Text)
            };
            JavaScriptSerializer sr = new JavaScriptSerializer();
            string jsonString = sr.Serialize(inputData);
            WebClient webClient = new WebClient();
            string request = $"http://localhost:45000/CalculatorX86?Object={jsonString}";
            string jsonResult = webClient.DownloadString(new Uri(request));
            Dictionary<string, CalculatorOutput> dict = sr.Deserialize<Dictionary<string, CalculatorOutput>>(jsonResult);
            
            txtResult.Text = dict["result"].ResultOfOperation.ToString();
        }
    }
}
