﻿var edgejs = require('edge-js');

var calculatorAccessFunc = edgejs.func(
{
    assemblyFile: '../CalculatorX86Accessor/bin/Debug/CalculatorX86Accessor.dll',
    typeName: 'CalculatorX86Accessor.Calculate',
    methodName: 'CalculationRequest'
});

function ProcessRequest(query, callback) {
    calculatorAccessFunc(query, function(error, result) { callback(error, result); });
}

module.exports = { ProcessRequest }