﻿var express = require('express');
var edgeJsLinkToX86Calculator = require('./EdgeJsLinkToX86Calculator');

var app = express();

app.use(express.json());

app.get('/CalculatorX86', function (req, res) {
    edgeJsLinkToX86Calculator.ProcessRequest(req.query, function (error, result) {
        if (error)
            res.status(500).json({ error });
        else
            res.status(200).json({ result });
    });
});

app.listen(process.env.PORT, function () { });