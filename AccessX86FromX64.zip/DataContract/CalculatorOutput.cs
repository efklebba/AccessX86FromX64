﻿using System;

namespace DataContract
{
    [Serializable]
    public class CalculatorOutput
    {
        public double ResultOfOperation { get; set; }
        public CalculatorInput InputObject { get; set; }
    }
}
