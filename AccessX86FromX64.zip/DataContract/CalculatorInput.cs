﻿using System;

namespace DataContract
{
    [Serializable]
    public class CalculatorInput
    {
        public CalculatorAction Action { get; set; }
        public double Value1 { get; set; }
        public double Value2 { get; set; }
    }
}
