﻿using System.Runtime.Serialization;

namespace DataContract
{
    [DataContract(Name = "CalculatorAction")]
    public enum CalculatorAction
    {
        [EnumMember]
        Add,

        [EnumMember]
        Subtract,

        [EnumMember]
        Multiply,

        [EnumMember]
        Divide
    }
}
